-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 24, 2025 at 04:53 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tester`
--

-- --------------------------------------------------------

--
-- Table structure for table `master_atm`
--

CREATE TABLE IF NOT EXISTS `master_atm` (
  `id_atm` varchar(50) NOT NULL,
  `nama_lokasi` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_atm`
--

REPLACE INTO `master_atm` (`id_atm`, `nama_lokasi`) VALUES
('T0900118', 'PDAM INTAN BANJAR'),
('T0901963', 'PT CPB 1'),
('T0901318', 'ALFAMART AWANG BANGKAL'),
('T0900842', 'BORNEO FUTSAL'),
('T0900843', 'MM PALEM'),
('T0900443', 'INDOMARET PANDU'),
('T0902167', 'STIKES HUSADA'),
('T0901589', 'ALFAMART SEKUMPUL'),
('T0900779', 'MESJID RAYA NURUL FALAH'),
('S1GM09A003', 'BLG BANJARBARU'),
('S1IBBRA020', 'ALFAMART INDRAGIRI'),
('S1IBBRA021', 'TOKO PUTRA'),
('S1IBBRA022', 'BUNDARAN PDAM'),
('S1IBBRA024', 'KK LANDASAN ULIN 3'),
('S1IBBRA025', 'PLN BBR 2'),
('S1IBBRA026', 'KK LANDASAN ULIN 1'),
('S1IBBRA029', 'PASAR GAMBUT'),
('S1IBBRA046', 'KCU BBR 3'),
('S1JBBRA011', 'PT SNI'),
('S1JBBRA005', 'MM GREEN MART'),
('S1CBBRA053', 'BPK RI KALSEL'),
('S1IBBRA041', 'RO ULIN'),
('S1EBBR90QO', 'RS BERSALIN AINUN'),
('S1GBBRA033', 'KEVIN RESORT 2'),
('S1JBBRA008', 'HOTEL SYARIAH MONTANA'),
('S1EBBR08LA', 'RS. MAWAR P. BATUR'),
('S1JBBIA001', 'SPBU KM 81'),
('S1GBBRA037', 'KANTOR IMIGRASI'),
('S1EBBR10JO', 'BATAS KOTA'),
('S1EBBI90QF', 'RSUD BRIGJ. H.HASAN BASRI'),
('S1JBBRA017', 'AUTO BRIDAL SUNGAI PARING'),
('S1EBBR08KV', 'KK CEMPAKA 4'),
('S1JBBRA013', 'INDOMARET BALITAN'),
('S1GBBIA025', 'KLN KANDANGAN 3'),
('S1IBBRA042', 'SPBU PERSADA BORNEO'),
('S1EBBR08KW', 'GAL KCP A YANI MTP 1'),
('S1GBBRA031', 'HOTEL DUTA'),
('S1IBBRA048', 'RSIA BORNEO CITRA MEDIKA'),
('S1FBBI11OV', 'KLN KANDANGAN 2'),
('S1JBBRA012', 'Q MALL'),
('S1EBBR10JN', 'PLN AP2B'),
('S1BBBR03SK', 'KK CEMPAKA 2'),
('S1FBBI11OW', 'SPBU BUNGUR'),
('S1EBBI90PN', 'ATM GALERY KCP BINUANG 2'),
('S1EBBR90QS', 'SPBU LANDASAN ULIN 1'),
('S1EBBR10JQ', 'SPBU GAMBUT'),
('S1IBBRA050', 'INDOMARET TRIKORA 2'),
('S1EBBR90QQ', 'AUTO SPEED'),
('S1IBBRA047', 'SPBU PT. PERSADA ENERGI'),
('S1JBBRA009', 'TOKO DHINI'),
('S1FBBR11OK', 'MM SEKUMPUL'),
('S1IBBRA049', 'GAL KCU BBR 7'),
('S1BBBR02WC', 'GAL KCU BBR 2'),
('S1GBBRA039', 'APOTIK HALIZA'),
('S1EBBR06DJ', 'GALERY KCP MARTAPURA 2'),
('S1IBBRA051', 'SUNGAI ULIN'),
('S1JBBRA001', 'LAPANGAN GOLF SWARGALOKA'),
('S1GBBR11CF', 'KK ASAM - ASAM'),
('S1IBBRA030', 'RSD IDAMAN BANJARBARU'),
('S1EBBR90QR', 'SPBU LANDASAN ULIN 2'),
('S1EBBR90QP', 'GAL KCU BBR 8'),
('S1CBBRA052', 'SIMPANG 4 ASAM ASAM 2'),
('S1JBBIA021', 'SPBU KM 94'),
('S1JBBIA003', 'ROCKET CHICKEN KM 77'),
('S1JBBIA022', 'JL. BAYPAS'),
('S1FBBI11ON', 'KK BINUANG'),
('S1EBBI06DI', 'KLN KANDANGAN 1'),
('S1EBBI10KA', 'GAL ATM KCP RANTAU'),
('S1FBBIA028', 'GAL KLN RANTAU 4'),
('S1ABBRR023', 'CRM KK LANDASAN ULIN '),
('S1ABBRR031', 'CRM KK CEMPAKA 3'),
('S1BBBRR017', 'CRM  GAL KLN PELAIHARI 1'),
('S1CBBRR010', 'KK LANDASAN ULIN CRM 2'),
('S1CBBRR011', 'KCP PELAIHARI CRM 3'),
('S1CBBRR012', 'KCP PELAIHARI CRM 2'),
('S1CBBRR013', 'KCP BANJARBARU CRM 4'),
('S1CBBRR014', 'CRM BDR SYAMSUDDIN NOOR'),
('S1CBBRR016', 'CRM GAL KCU BBR 9'),
('S1CBBRR018', 'CRM UNLAM PASCA SARJANA'),
('S1CBBRR022', 'CRM SPBU LIANG ANGGANG'),
('S1CBBRR027', 'CRM PT. JAFPA COMFEED'),
('S1CBBRR028', 'CRM CAFE FELLAS'),
('S1DBBIR014', 'CRM GAL KLN RANTAU 2'),
('S1DBBRR015', ' CRM KK CEMPAKA 1'),
('S1EBBRR001', 'KK LANDASAN ULIN CRM'),
('S1EBBRR002', 'GAL KCP A YANI CRM MTP 2'),
('S1EBBRR004', 'KEVIN RESORT CRM'),
('S1EBBRR019', 'GALERY KCP MARTAPURA 1'),
('S1EBBRR020', 'CRM PEMKO/BALAI KOTA'),
('S1EBBRR021', 'CRM SIMPANG 3 BATI-BATI'),
('S1EBBRR024', ' CRM GAL KCU BBR 4'),
('S1EBBRR025', 'CRM RSUD RATU ZALEHA'),
('S1EBBRR029', 'SPBU ASTAMBUL'),
('S1EBBRR030', 'CRM SPBU SURYA ANUGRAH UTAMA'),
('S1FBBRR026', 'PEMKAB BANJAR'),
('S1IBBRR005', 'KK ASAM-ASAM CRM'),
('S1IBBRR006', 'KC BANJAR BARU CRM 1'),
('S1JBBIR002', 'MRV BINUANG CRM'),
('S1JBBIR003', 'KK CRM KANDANGAN'),
('S1JBBIR006', 'MESJID TAPIN'),
('S1JBBIR007', 'KK BINUANG CRM'),
('S1JBBIR020', 'GAL KLN RANTAU 3 CRM'),
('S1JBBRR003', ' KLN PELAIHARI CRM'),
('S1JBBRR007', 'KK CEMPAKA CRM'),
('S1JBBRR008', '  KCU BBR 5 CRM'),
('S1JBBRR009', 'KCU BANJAR BARU CRM 2'),
('HYS0010803(T2010803)', 'BTN INDOMARET SPBU GUNTUNG MANGGIS'),
('WIN0010804', 'SEKUMPUL MARTAPURA'),
('WIN0010805', 'MUSTIKA JAYA'),
('WIN0010806', 'PDAM INTAN BANJAR'),
('WIN0010801', 'INDMRT MISTAR COKRO'),
('WIN0010802', 'KC BANJARBARU 2'),
('HYO0010807', 'CRM KC BANJARBRU'),
('HTC0010811', 'CRM BTN ULIN'),
('HTC0010813', 'CRM KCPS BANJARBARU'),
('HTC0010812', 'CRM KC BANJARBARU 2'),
('HTC0010809', 'MKK BANJARBARU'),
('BTP1072', 'BTPN KANDANGAN'),
('BTP1112', 'BTPN CAB BATAS KOTA'),
('B395', 'QMALL'),
('B714', 'IND.KM 41'),
('B715', 'IND.KM 33,9'),
('B170', 'BANDARA'),
('A0254002', 'ATM STIEPAN BANJARBARU'),
('A0123001', 'ATM RS IDAMAN'),
('A0123002', 'ATM FUTSAL BORNEO'),
('3914', 'MARTAPURA ADIRA AHMAD YANI');

-- --------------------------------------------------------

--
-- Table structure for table `pemakaian_part`
--

CREATE TABLE IF NOT EXISTS `pemakaian_part` (
  `no_tiket` varchar(50) NOT NULL,
  `id_atm` varchar(50) NOT NULL,
  `nama_lokasi` varchar(255) NOT NULL,
  `mesin` varchar(50) NOT NULL,
  `nama_teknisi` varchar(255) NOT NULL,
  `nama_sparepart` varchar(100) NOT NULL,
  `part_number` varchar(50) NOT NULL,
  `sn_good` varchar(50) NOT NULL,
  `sn_bad` varchar(50) NOT NULL,
  `detail_kerusakan` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemakaian_part`
--

REPLACE INTO `pemakaian_part` (`no_tiket`, `id_atm`, `nama_lokasi`, `mesin`, `nama_teknisi`, `nama_sparepart`, `part_number`, `sn_good`, `sn_bad`, `detail_kerusakan`) VALUES
('WKS001', 'S1JBBIA021', 'SPBU KM 94', 'WINCOR          ', 'ADRIAN', 'DOUBLE EXTRACTOR UNIT MDMS CMD-V4          ', '1750109641          ', '1322094859421          ', '133211077111', 'mati'),
('WKS002', 'S1JBBIA021', 'SPBU KM 94', 'WINCOR          ', 'M HAFIZ ANSHARI', 'CONTROLLER CMD          ', '1750105679          ', '1322094890827          ', 'NO SN', 'Mati Total');

-- --------------------------------------------------------

--
-- Table structure for table `sparepart`
--

CREATE TABLE IF NOT EXISTS `sparepart` (
  `part_number` varchar(50) DEFAULT NULL,
  `nama_sparepart` varchar(100) DEFAULT NULL,
  `jenis_part` varchar(50) DEFAULT NULL,
  `atm` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sparepart`
--

REPLACE INTO `sparepart` (`part_number`, `nama_sparepart`, `jenis_part`, `atm`) VALUES
('CDLGST', 'CDRW LARGE SATA', 'Tidak Bisa Diperbaiki', 'ALL'),
('FDD144', 'FLOPPY DRIVE BLS1VE-FLX 1,44MB', 'Tidak Bisa Diperbaiki', 'ALL'),
('HDLG500ST', 'HARDISK LARGE 500 GB', 'Tidak Bisa Diperbaiki', 'ALL'),
('HDLG80IDE', 'HARDISK LARGE 80 GB', 'Tidak Bisa Diperbaiki', 'ALL'),
('HDSM320ST', 'HARDISK SMALL 320 GB', 'Tidak Bisa Diperbaiki', 'ALL'),
('HDSM500ST', 'HARDISK SMALL 500 GB', 'Tidak Bisa Diperbaiki', 'ALL'),
('SCR-1K', 'UPS EDCON SCR-01 1KVA', 'Bisa Diperbaiki', 'ALL'),
('7310000733', 'ASSY CARRIAGE (TANGAN ROBOT)', 'Bisa Diperbaiki', 'HYO'),
('7760000064', 'PCBA CDU 10 MAINBOARD ATAS', 'Bisa Diperbaiki', 'HYO'),
('7760000065', 'BOARD PCBA FM (BOARD BAWAH)', 'Bisa Diperbaiki', 'HYO'),
('7460000002', 'BOARD PNC', 'Bisa Diperbaiki', 'HYO'),
('5645000001', 'CARD READER SANKYO', 'Bisa Diperbaiki', 'HYO'),
('7010000308', 'CDU 10 (STACKER) ', 'Bisa Diperbaiki', 'HYO'),
('5611000203B', 'CE30 (MAINBOARD :G41M:AMI PC Ci3)', 'Bisa Diperbaiki', 'HYO'),
('5611000203A', 'CE30 (MAINBOARD :G41M:MSI PC C2D)', 'Bisa Diperbaiki', 'HYO'),
('5611000203BMB', 'MAINBOARD CE30 (MAINBOARD :G41M:AMI PC Ci3)', 'Tidak Bisa Diperbaiki', 'HYO'),
('5661000110', 'LCD 15" DS-5600', 'Bisa Diperbaiki', 'HYO'),
('5621000036', 'POWER SUPPLY HPS280', 'Bisa Diperbaiki', 'HYO'),
('7020000046', 'RECEIPT PRINTER SPR 24 (TUNAI)', 'Bisa Diperbaiki', 'HYO'),
('7310000725', 'ROTOR CARRIAGE', 'Bisa Diperbaiki', 'HYO'),
('7430000255', 'SEPARATOR LOWER 3-4', 'Bisa Diperbaiki', 'HYO'),
('7310000386', 'SEPARATOR UPPER 1-2', 'Bisa Diperbaiki', 'HYO'),
('7430000301', 'THROAT_FR /EXIT SHUTTER', 'Bisa Diperbaiki', 'HYO'),
('7130110100', 'EPP 8000K', 'Tidak Bisa Diperbaiki', 'HYO'),
('7310000649', 'RACK CASSETTE HYOSUNG', 'Tidak Bisa Diperbaiki', 'HYO'),
('4450704484', 'CARD READER NCR ss22E', 'Bisa Diperbaiki', 'NCR'),
('4450718416', 'S1 DISPENSER CONTROL BOARD SS22E', 'Bisa Diperbaiki', 'NCR'),
('90026887', 'LCD NCR SS22E', 'Bisa Diperbaiki', 'NCR'),
('4450689219', 'PICK I/F DOUBLE (DOUBLE PICK I/F CONTROL BOARD - ASSY)', 'Bisa Diperbaiki', 'NCR'),
('4450671759', 'PICK MODULE ARIA', 'Bisa Diperbaiki', 'NCR'),
('4450724941', 'PRESENTER NCR 22E', 'Bisa Diperbaiki', 'NCR'),
('90025345', 'RECEIPT PRINTER SS22E', 'Bisa Diperbaiki', 'NCR'),
('4450721021', 'SHUTTER ASSY LOWER MOTOR RHS SS22E', 'Bisa Diperbaiki', 'NCR'),
('4450735609', 'EPP SS22E', 'Tidak Bisa Diperbaiki', 'NCR'),
('ATMUSBK', 'ATMDESK USB KEY', 'Tidak Bisa Diperbaiki', 'NCR'),
('90025595', 'POWER SUPPLY SS22E', 'Bisa Diperbaiki', 'NCR'),
('4450728233A', 'KINGSWAY MB INTEL GL40 WITH SATA X3 SS22E PC C2D', 'Tidak Bisa Diperbaiki', 'NCR'),
('4450728233B', 'KINGSWAY MB INTEL GL40 WITH SATA X3 SS22E PC Ci3', 'Bisa Diperbaiki', 'NCR'),
('4450767382', 'ESTORIL MAINBOARD NCR', 'Tidak Bisa Diperbaiki', 'NCR'),
('4450704535', 'ASSY - 15in FDK PCB LH SS22E', 'Tidak Bisa Diperbaiki', 'NCR'),
('4450704530', 'ASSY - 15in FDK PCB RH SS22E', 'Tidak Bisa Diperbaiki', 'NCR'),
('HRNSNCRSSE', 'CABLE HARNESS NCR SS22E', 'Tidak Bisa Diperbaiki', 'NCR'),
('90024352', 'CAMERA ATAS NCR SS22E', 'Tidak Bisa Diperbaiki', 'NCR'),
('4450725392', 'MINI-MISC - PCB ASSY SS22E (BNI)', 'Bisa Diperbaiki', 'NCR'),
('1750199931', 'CARD READER CHD V2CU ACT VERSION', 'Bisa Diperbaiki', 'WINCOR'),
('1750173205', 'CARD READER CHD V2CU STANDARD (NO CONTRACT)', 'Bisa Diperbaiki', 'WINCOR'),
('1750136159', 'CENTRAL POWER PACK USB', 'Bisa Diperbaiki', 'WINCOR'),
('1750263469', 'CENTRAL POWER PACK USB FOR 280N', 'Bisa Diperbaiki', 'WINCOR'),
('1750105679', 'CONTROLLER CMD', 'Bisa Diperbaiki', 'WINCOR'),
('1750235765', 'CPU BETTLE MINI 280', 'Bisa Diperbaiki', 'WINCOR'),
('1750044878', 'Distributor Board 4X With Cover', 'Bisa Diperbaiki', 'WINCOR'),
('1750109615', 'DOUBLE EXTRACTOR UNIT CMD-V4', 'Bisa Diperbaiki', 'WINCOR'),
('1750109641', 'DOUBLE EXTRACTOR UNIT MDMS CMD-V4', 'Bisa Diperbaiki', 'WINCOR'),
('1750106679', 'EMBEDDED PC 1500', 'Bisa Diperbaiki', 'WINCOR'),
('1750078980', 'LCD 280', 'Bisa Diperbaiki', 'WINCOR'),
('1750262934', 'LC 15" OPENFRAME PROCASH 280N', 'Bisa Diperbaiki', 'WINCOR'),
('1750169942', 'LCD BOX 2 PC1500', 'Bisa Diperbaiki', 'WINCOR'),
('1750189334', 'PRINTER TP13 280', 'Bisa Diperbaiki', 'WINCOR'),
('1750256248', 'RECEIPT PRINTER TP28', 'Bisa Diperbaiki', 'WINCOR'),
('1750063915', 'RECEIPT PRINTER TP07', 'Bisa Diperbaiki', 'WINCOR'),
('1750082602', 'SHUTTER 1500XE', 'Bisa Diperbaiki', 'WINCOR'),
('1750220136', 'SHUTTER-LITE DC-MOTOR ASSY PC28X', 'Bisa Diperbaiki', 'WINCOR'),
('1750109659', 'STACKER CMD', 'Bisa Diperbaiki', 'WINCOR'),
('1750263073', 'SWAP PC 5G I3 P280N', 'Bisa Diperbaiki', 'WINCOR'),
('1750068776', 'TRANSPORT CMD V-4 HORIZONTAL FL 125 MM', 'Bisa Diperbaiki', 'WINCOR'),
('1750057875', 'TRANSPORT CMD V-4 HORIZONTAL FL 101 MM', 'Bisa Diperbaiki', 'WINCOR'),
('1750073167', 'POWER DISTRIBUTOR 1500 (USB)', 'Bisa Diperbaiki', 'WINCOR'),
('1750159341', 'EPP V6 INTERNATIONAL', 'Tidak Bisa Diperbaiki', 'NCR'),
('1750233014', 'KEYBOARD J6.1 EPP IDN (EPP J6.1)', 'Tidak Bisa Diperbaiki', 'NCR'),
('1750073862', 'Tombol SOP', 'Tidak Bisa Diperbaiki', 'WINCOR'),
('1750211175', 'TPK-OPTERA 15 in 3mm Cap Sentuh w/ control', 'Tidak Bisa Diperbaiki', 'NCR'),
('1750211130', 'PROTECTIVE GLASS TOUCH SCREEN 280N', 'Tidak Bisa Diperbaiki', 'NCR'),
('1803530375', '15" Protective Glass PC280 (15" PROTECT GLASS', 'Tidak Bisa Diperbaiki', 'NCR'),
('1750192235', 'Base Unit ASKIM  - II D (BASE UNIT ASKIM II DD)', 'Bisa Diperbaiki', 'WINCOR'),
('HRNSWIN280', 'CABLE HARNESS PC280', 'Tidak Bisa Diperbaiki', 'WINCOR'),
('6221306535', 'CAPACITOR ALUMINUM;150MF;35VDC; 105MM/ELKO', 'Tidak Bisa Diperbaiki', 'WINCOR'),
('1750192200', 'GAS SPRING 450N WINCOR (strut gas spring)', 'Tidak Bisa Diperbaiki', 'WINCOR'),
('1803530466', 'PINTU FASCIA ATAS PC280 (TARIK KEATAS)', 'Tidak Bisa Diperbaiki', 'WINCOR'),
('1803530359', 'PINTU FASCIA BAWAH PC280', 'Tidak Bisa Diperbaiki', 'WINCOR'),
('1750190038', 'SOFTKEY FRAME 15 INCH DDC-NDC BR PC28X', 'Bisa Diperbaiki', 'WINCOR'),
('1750187952', 'SPECIAL ELEKTRONIK 280', 'Bisa Diperbaiki', 'WINCOR'),
('1750210306', 'USB 2.0 Hub 7-Port', 'Bisa Diperbaiki', 'WINCOR'),
('1750130600', 'V-MODULE (CMD-CHASSIS NT ASSD. QUAD.)', 'Tidak Bisa Diperbaiki', 'WINCOR');

-- --------------------------------------------------------

--
-- Table structure for table `sp_bjm`
--

CREATE TABLE IF NOT EXISTS `sp_bjm` (
  `part_number` varchar(50) NOT NULL,
  `nama_sparepart` varchar(100) NOT NULL,
  `jenis_sparepart` varchar(50) NOT NULL,
  `atm` varchar(50) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_bjm`
--


-- --------------------------------------------------------

--
-- Table structure for table `sp_mth`
--

CREATE TABLE IF NOT EXISTS `sp_mth` (
  `part_number` varchar(50) NOT NULL,
  `nama_sparepart` varchar(100) NOT NULL,
  `jenis_sparepart` varchar(50) NOT NULL,
  `atm` varchar(50) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_mth`
--


-- --------------------------------------------------------

--
-- Table structure for table `sp_pkb`
--

CREATE TABLE IF NOT EXISTS `sp_pkb` (
  `part_number` varchar(50) NOT NULL,
  `nama_sparepart` varchar(100) NOT NULL,
  `jenis_sparepart` varchar(50) NOT NULL,
  `atm` varchar(50) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_pkb`
--


-- --------------------------------------------------------

--
-- Table structure for table `sp_plk`
--

CREATE TABLE IF NOT EXISTS `sp_plk` (
  `part_number` varchar(50) NOT NULL,
  `nama_sparepart` varchar(100) NOT NULL,
  `jenis_sparepart` varchar(50) NOT NULL,
  `atm` varchar(50) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_plk`
--


-- --------------------------------------------------------

--
-- Table structure for table `sp_spt`
--

CREATE TABLE IF NOT EXISTS `sp_spt` (
  `part_number` varchar(50) NOT NULL,
  `nama_sparepart` varchar(100) NOT NULL,
  `jenis_sparepart` varchar(50) NOT NULL,
  `atm` varchar(50) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_spt`
--

REPLACE INTO `sp_spt` (`part_number`, `nama_sparepart`, `jenis_sparepart`, `atm`, `barcode`, `status`) VALUES
('ATMUSBK', 'ATMDESK USB KEY', 'Tidak Bisa Diperbaiki', 'NCR', '1032211659778', 'BAD');

-- --------------------------------------------------------

--
-- Table structure for table `sp_tjg`
--

CREATE TABLE IF NOT EXISTS `sp_tjg` (
  `part_number` varchar(50) NOT NULL,
  `nama_sparepart` varchar(100) NOT NULL,
  `jenis_sparepart` varchar(50) NOT NULL,
  `atm` varchar(50) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_tjg`
--


-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

REPLACE INTO `user` (`username`, `password`) VALUES
('admin', '0192023a7bbd73250516f069df18b500'),
('J95607', 'd9037c9466dc1f1cc9d852f8ffec91c5');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
