<?php
$koneksi = mysqli_connect("localhost", "root", "", "tester2");

// Cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
