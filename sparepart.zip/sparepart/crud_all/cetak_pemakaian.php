<?php 
// 1. PASTIKAN PATH INI BENAR untuk memuat $koneksi dan GetSQLValueString
require_once('../function_all/function_pemakaianSP.php'); 

// Pastikan variabel $koneksi tersedia setelah require
if (!isset($koneksi)) {
    die("Error: Koneksi database tidak tersedia. Cek path di require_once.");
}

// 2. Ambil No Tiket dari URL
if (!isset($_GET['no_tiket']) || empty($_GET['no_tiket'])) {
    die("Error: No Tiket tidak ditemukan.");
}

$no_tiket = $_GET['no_tiket'];

// 3. Ambil Data dari Database
// Nama tabel digunakan adalah 'pemakaian_part'
$query_cetak = sprintf(
    "SELECT * FROM pemakaian_part WHERE no_tiket = %s",
    GetSQLValueString($no_tiket, "text")
);

$Recordset_Cetak = mysqli_query($koneksi, $query_cetak) or die(mysqli_error($koneksi));
$data_cetak = mysqli_fetch_assoc($Recordset_Cetak);

if (!$data_cetak) {
    die("Error: Data pemakaian sparepart untuk Tiket " . htmlspecialchars($no_tiket) . " tidak ditemukan.");
}

// 4. Output HTML Print-Friendly Dimulai
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <title>Laporan Pemakaian Sparepart - <?= htmlspecialchars($no_tiket) ?></title>
    <style>
        /* CSS yang ditingkatkan */
        body { 
            font-family: 'Times New Roman', Times, serif; 
            font-size: 11pt; 
            margin: 0; 
            padding: 0;
            color: #333;
        }
        .container { 
            width: 90%; 
            margin: 30px auto; 
        }
        /* --- HEADER LOGO --- */
        .header-print {
            display: flex;
            align-items: center;
            border-bottom: 3px solid #000;
            padding-bottom: 10px;
            margin-bottom: 25px;
        }
        .header-print img {
            max-height: 60px; /* Atur ukuran logo */
            margin-right: 20px;
        }
        .header-print h1 {
            margin: 0;
            font-size: 18pt;
            font-weight: bold;
            color: #000;
            flex-grow: 1;
            text-align: center;
        }
        /* --- DETAIL TABEL --- */
        .data-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 30px; 
            border: 1px solid #000; 
        }
        /* Style untuk setiap sel */
        .data-table tr td { 
            padding: 8px 15px; /* Padding sedikit dikurangi */
            text-align: left; 
            vertical-align: top;
            border: 1px solid #ccc; 
        }
        .label { 
            font-weight: bold; 
            width: 30%; 
            background-color: #f8f8f8; 
        }
        
        .no-print { text-align: center; margin-top: 30px; }
        
        @media print {
            .no-print { display: none; }
            * { -webkit-print-color-adjust: exact !important; color-adjust: exact !important; }
        }
    </style>
</head>
<body>
    <div class="container">
        
        <div class="header-print">
            <img src="../img/logo.png" alt="Logo Perusahaan">
            <h1>LAPORAN PEMAKAIAN SPAREPART</h1>
        </div>
        
        <p style="text-align: center; font-size: 14pt; margin-top: 0; margin-bottom: 20px;">No Tiket: <?= htmlspecialchars($data_cetak['no_tiket']) ?></p>
        
        <table class="data-table">
            <tr>
                <td class="label">ID ATM</td>
                <td><?= htmlspecialchars($data_cetak['id_atm'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Nama Lokasi</td>
                <td><?= htmlspecialchars($data_cetak['nama_lokasi'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Mesin</td>
                <td><?= htmlspecialchars($data_cetak['mesin'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Nama Teknisi</td>
                <td><?= htmlspecialchars($data_cetak['nama_teknisi'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Nama Sparepart</td>
                <td><?= htmlspecialchars($data_cetak['nama_sparepart'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Jenis Sparepart</td>
                <td><?= htmlspecialchars($data_cetak['jenis_sparepart'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Part Number (P/N)</td>
                <td><?= htmlspecialchars($data_cetak['part_number'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Serial Number (SN) Dipasang</td>
                <td><?= htmlspecialchars($data_cetak['sn_good'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Serial Number (SN) Dilepas</td>
                <td><?= htmlspecialchars($data_cetak['sn_bad'] ?? '-') ?></td>
            </tr>
            <tr>
                <td class="label">Detail Kerusakan</td>
                <td><?= nl2br(htmlspecialchars($data_cetak['detail_kerusakan'] ?? '-')) ?></td>
            </tr>
        </table>

        <div style="width: 100%; display: flex; justify-content: flex-end; margin-top: 50px;">
            <div style="width: 250px; text-align: center;">
                <p style="margin-bottom: 70px;">Hormat Kami,</p>
                <p style="border-top: 1px solid #000; padding-top: 5px;">(<?= htmlspecialchars($data_cetak['nama_teknisi'] ?? 'Nama Teknisi') ?>)</p>
            </div>
        </div>
        
        <div class="no-print">
            <button onclick="window.print()">Cetak Dokumen</button>
            <button onclick="window.close()">Tutup</button>
        </div>
    </div>
    
    <script>
        // Memicu dialog cetak secara otomatis
        window.onload = function() {
            window.print();
        }
    </script>
</body>
</html>
<?php
// Bebaskan hasil query
if (isset($Recordset_Cetak)) {
    mysqli_free_result($Recordset_Cetak);
}
?>