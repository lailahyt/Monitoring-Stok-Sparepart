<?php
session_start();
require_once('../Connections/koneksi.php'); 

// Cegah akses jika bukan admin
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    echo "Akses ditolak!";
    exit;
}

// =======================
// MAPPING USER -> TEKNISI
// =======================
$userTeknisiMap = [
    'J95602' => 'Adriann',
    'J95603' => 'Muhammad Zaqi Habibie',
    'J95604' => 'Muhammad Nahyyij Husaibi',
    'J95610' => 'Rizky',
    'J95611' => 'Muhammad Ikhsan',
    'J95605' => 'Prahara Bayu Kusuma',
    'J95606' => 'Sulis Setiawan',
    'J95607' => 'M.Hafiz Anshari',
    'J95608' => 'Yusril Mahendra',
    'J95609' => 'Aidi Ramadhani',
    'admin'  => 'ALL'
];

// =======================
// MAPPING USER -> TABEL
// (sp_bjm tidak dimasukkan)
// =======================
$userSparepartTable = [
    'J95602' => 'sp_bjb',
    'J95603' => 'sp_btl',
    'J95605' => 'sp_mth',
    'J95606' => 'sp_spt',
    'J95607' => 'sp_plk',
    'J95608' => 'sp_pkb',
    'J95609' => 'sp_tjg'
];

// =======================
// BALIKAN: TABEL -> USER
// =======================
$tableToUser = array_flip($userSparepartTable);

// Ambil parameter tabel
if (!isset($_GET['tabel'])) {
    echo "Parameter tabel tidak ditemukan!";
    exit;
}

$tabel = $_GET['tabel'];

// ================================
// Tentukan nama teknisi berdasar TABEL
// ================================
$namaTeknisi = "—"; // default

if (isset($tableToUser[$tabel])) {
    $usernameTeknisi = $tableToUser[$tabel];

    if (isset($userTeknisiMap[$usernameTeknisi])) {
        $namaTeknisi = $userTeknisiMap[$usernameTeknisi];
    }
}

// Query data sparepart
$query = mysqli_query($koneksi, "SELECT * FROM $tabel ORDER BY nama_sparepart ASC");
if (!$query) {
    echo "Gagal mengambil data sparepart!";
    exit;
}

// Hitung stok
$stok = mysqli_num_rows($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Cetak Data Sparepart</title>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
}
.header-wrapper {
    width: 100%;
    margin-bottom: 25px;
}

.header-top {
    display: flex;
    align-items: center;
    gap: 7px;
}

.header-title-big {
    font-size: 22px;
    font-weight: bold;
    text-transform: uppercase;
    text-align: center;
    flex-grow: 1;
    margin: 0;
}

.header-line {
    margin-top: 8px;
    margin-bottom: 8px;
    border-bottom: 2px solid #000;
}

.header-info {
    display: flex;
    justify-content: space-between;
    font-size: 15px;
    margin-top: 3px;
}

.table-sp {
    width: 100%;
    border-collapse: collapse;
    margin-top: 17px;
}
.table-sp th, .table-sp td {
    border: 1px solid #000;
    padding: 8px;
    font-size: 14px;
}
.table-sp th {
    background-color: #f0f0f0;
}
.sub-info {
    margin-top: 5px;
    font-size: 14px;
}
</style>

<script>
window.onload = function() {
    window.print();
};
</script>

</head>
<body>

<div class="header-wrapper">

    <div class="header-top">
        <div class="logo">
            <img src="../img/logo.png" alt="SSI Logo" style="height: 60px;">
        </div>

        <div class="header-title-big">
            DATA STOK SPAREPART
        </div>
    </div>

    <!-- Garis pembatas -->
    <div class="header-line"></div>

    <!-- Teknisi kiri, Stok kanan -->
    <div class="header-info">
        <div class="info-left">Teknisi : <b><?php echo $namaTeknisi; ?></b></div>
        <div class="info-right">Total Stok : <b><?php echo $stok; ?></b></div>
    </div>

</div>

<table class="table-sp">
    <thead>
        <tr>
            <th>No</th>
            <th>Part Number</th>
            <th>Nama Sparepart</th>
            <th>Jenis</th>
            <th>Merk ATM</th>
            <th>Status</th>
        </tr>
    </thead>

    <tbody>
        <?php 
        $no = 1;
        while ($row = mysqli_fetch_assoc($query)) { ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo htmlspecialchars($row['part_number']); ?></td>
            <td><?php echo htmlspecialchars($row['nama_sparepart']); ?></td>
            <td><?php echo htmlspecialchars($row['jenis_sparepart']); ?></td>
            <td><?php echo htmlspecialchars($row['atm']); ?></td>
            <td><?php echo htmlspecialchars($row['status']); ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>

</body>
</html>
