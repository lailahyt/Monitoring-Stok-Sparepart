<?php 
require_once('../Connections/koneksi.php'); 

$dataTeknisi = [];
$dataJumlah  = [];

$query = "
    SELECT nama_teknisi, COUNT(*) AS total_pemakaian
    FROM pemakaian_part
    GROUP BY nama_teknisi
    ORDER BY total_pemakaian DESC
";

$result = mysqli_query($koneksi, $query);
if (!$result) {
    die("Query gagal: " . mysqli_error($koneksi));
}

$totalPemakaian = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $dataTeknisi[] = $row['nama_teknisi'];
    $dataJumlah[]  = $row['total_pemakaian'];
    $totalPemakaian += $row['total_pemakaian'];
}

$totalTeknisi = count($dataTeknisi);

ob_start();
?>

<div class="container-fluid mt-4">

    <!-- Judul Dashboard -->
    <div class="mb-4">
        <h3 class="font-weight-bold">Dashboard Pemakaian Sparepart</h3>
        <p class="text-muted mb-0">
            Ringkasan pemakaian sparepart berdasarkan aktivitas teknisi
        </p>
    </div>

    <!-- Summary Card -->
    <div class="row mb-4">
        <div class="col-md-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <div class="mr-3 text-primary">
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                    <div>
                        <h6 class="mb-0 text-muted">Total Teknisi</h6>
                        <h4 class="mb-0 font-weight-bold"><?= $totalTeknisi; ?></h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <div class="mr-3 text-success">
                        <i class="fas fa-box-open fa-2x"></i>
                    </div>
                    <div>
                        <h6 class="mb-0 text-muted">Total Pemakaian Sparepart</h6>
                        <h4 class="mb-0 font-weight-bold"><?= $totalPemakaian; ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Grafik -->
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white">
            <h5 class="mb-0 font-weight-bold">
                Grafik Pemakaian Sparepart per Teknisi
            </h5>
        </div>
        <div class="card-body">
            <canvas id="grafikPemakaian" height="200"></canvas>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById('grafikPemakaian');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($dataTeknisi); ?>,
            datasets: [{
                label: 'Jumlah Sparepart Terpakai',
                data: <?= json_encode($dataJumlah); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.75)',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                display: true
            },
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        precision: 0
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Jumlah Pemakaian'
                    }
                }],
                xAxes: [{
                    scaleLabel: {
                        display: true,
                        labelString: 'Nama Teknisi'
                    }
                }]
            }
        }
    });
});
</script>

<?php
$main_content = ob_get_clean();
include '../template.php';
?>
