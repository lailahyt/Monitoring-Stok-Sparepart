<?php
session_start();

// Tambahkan header anti-cache
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// ✅ Jika user ingin memaksa kembali ke halaman login (tanpa harus logout manual)
if (isset($_GET['login']) && $_GET['login'] == 'true') {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}

// ✅ Jika user sudah login, arahkan ke halaman sesuai peran
if (isset($_SESSION['username'])) {
    $username_trim = strtoupper(trim($_SESSION['username']));

    switch ($username_trim) {
        case 'ADMIN':
            header("Location: admin/dashboard.php");
            break;
        case 'J95602':
            header("Location: teknisi/teknisi_bjb.php");
            break;
        case 'J95603':
            header("Location: teknisi/teknisi_btl.php");
            break;
        case 'J95604':
            header("Location: teknisi/teknisi_bjm.php");
            break;
        case 'J95605':
            header("Location: teknisi/teknisi_mth.php");
            break;
        case 'J95606':
            header("Location: teknisi/teknisi_spt.php");
            break;
        case 'J95607':
            header("Location: teknisi/teknisi_plk.php");
            break;
        case 'J95608':
            header("Location: teknisi/teknisi_pkb.php");
            break;
        case 'J95609':
            header("Location: teknisi/teknisi_tjg.php");
            break;
        default:
            header("Location: index.php?error=role_not_found");
            break;
    }
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            /* Pertahankan background dark overlay dan gambar */
            background: 
                linear-gradient(
                    rgba(33, 37, 41, 0.75),
                    rgba(33, 37, 41, 0.75)
                ),
                url("img/ssi-bjm.jpeg");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 15px;
        }

        .login-card {
            border: none; 
            border-radius: 15px; 
            /* UBAH: Padding disetel untuk mengkompensasi header baru */
            padding: 0 0 40px 0; 
            width: 100%;
            max-width: 400px; 
            animation: fadeInUp 0.6s ease;
            backdrop-filter: blur(15px);
            /* BACKGROUND PUTIH */
            background: rgba(255, 255, 255, 0.9); 
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }
        
        /* --- STYLING HEADER GRADIENT BARU --- */
        .login-header{
            /* GRADIENT MERAH SSI */
            background: linear-gradient(90deg, #8f0f14, #b11217); 
            padding: 25px 30px; 
            color: white;
            /* Sudut membulat hanya di atas */
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2); 
            margin-bottom: 25px; /* Jarak ke konten form */
        }
        /* --- END STYLING HEADER GRADIENT BARU --- */


        .login-header h3 {
            color: white !important; /* Pastikan teks di header tetap putih */
            text-align: center;
            font-weight: 700;
            margin: 0; /* Hapus margin default h3 di dalam header */
            font-size: 28px;
        }

        /* Tambahkan padding horizontal untuk form content */
        .login-card form {
            padding: 0 40px; 
        }

        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        .input-group {
            position: relative;
        }

        .input-group-prepend {
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            display: flex;
            align-items: center;
            z-index: 10;
            pointer-events: none;
        }

        .input-group-text {
            border: none;
            background: transparent;
            color: #777; 
            padding-left: 15px;
        }

        .form-control {
            background: #f8f9fa; 
            border: 1px solid #ddd;
            color: #333; 
            border-radius: 10px; 
            padding: 12px 20px 12px 45px;
            width: 100%;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            background: #fff; 
            border-color: #B11217; 
            box-shadow: 0 0 10px rgba(177, 18, 23, 0.4); 
            color: #333;
            outline: none;
        }

        .form-control::placeholder {
            color: #999; 
        }

        .btn-login {
            border-radius: 10px; 
            background: #B11217; 
            color: #fff;
            font-weight: bold;
            transition: all 0.3s ease;
            padding: 12px 20px;
            border: none;
            width: 100%;
            font-size: 16px;
            margin-top: 15px; 
            letter-spacing: 0.5px;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            background: #8f0f14; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.5);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .login-alert {
            /* Margin horizontal disesuaikan agar sama dengan padding form */
            margin: 0 40px 15px 40px;
            color: #B11217; 
            font-size: 14px;
            text-align: center;
            padding: 8px;
            border-radius: 5px;
            background: rgba(177, 18, 23, 0.1); 
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Mobile Optimization */
        @media (max-width: 640px) {
            body {
                padding: 20px 10px;
            }

            .login-card {
                padding: 0 0 25px 0; /* Kurangi padding bawah untuk mobile */
                border-radius: 15px;
            }

            .login-header {
                padding: 20px 25px;
                margin-bottom: 20px;
            }

            .login-header h3 {
                font-size: 24px;
            }

            .login-card form {
                padding: 0 25px; /* Kurangi padding horizontal untuk mobile */
            }

            .login-alert {
                margin: 0 25px 15px 25px; /* Kurangi margin horizontal untuk mobile */
            }

            .form-control {
                padding: 11px 18px 11px 42px;
                font-size: 14px;
            }

            .input-group-text {
                padding-left: 13px;
            }

            .btn-login {
                font-size: 15px;
                padding: 11px 18px;
            }
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="login-header">
            <h3>Form Login</h3>
        </div>
        <?php if (isset($_GET['error']) && $_GET['error'] == 1): ?>
            <div class="login-alert">
                <i class="fas fa-exclamation-circle"></i>
                Username atau Password salah!
            </div>
        <?php endif; ?>
        
        <form action="function_all/cek_login.php" method="post">
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                    </div>
                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                </div>
            </div>
            
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    </div>
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
            </div>
            
            <button type="submit" class="btn btn-login">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
    </div>
</body>
</html>